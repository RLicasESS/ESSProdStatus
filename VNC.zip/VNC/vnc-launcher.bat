@echo off
set raw=%1

REM Remove quotes
set raw=%raw:"=%

REM Strip vnc:// prefix
set device=%raw:vnc://=%

REM Strip trailing slashes (AP-1/ → AP-1)
IF "%device:~-1%"=="/" set device=%device:~0,-1%

REM Strip trailing query (?x=y)
for /f "delims=? tokens=1" %%a in ("%device%") do set device=%%a

echo Device: %device%

REM ===== Device → IP/Password Map =====

IF /I "%device%"=="AP-1" goto AP1
IF /I "%device%"=="AP-2" goto AP2
IF /I "%device%"=="S100-1" goto S1001
IF /I "%device%"=="S100-2" goto S1002

echo ERROR: Unknown device "%device%"
exit /b

:AP1
set ip=172.18.148.141
set pass=C:\VNC\passwd_AP
goto launch

:AP2
REM set ip=172.18.97.10 
set ip=10.20.10.26                  
set pass=C:\VNC\passwd_AP
goto launch

:S1001
set ip=10.20.10.52
set pass=C:\VNC\passwd_S100
goto launch

:S1002
set ip=10.20.10.31
set pass=C:\VNC\passwd_S100
goto launch

:launch
start "" "C:\Users\RLicas\OneDrive - ESS Technology\PYTHON\ESSPRODMON\ESSProdStatus\vncviewer64-1.16.80.exe" -passwd=%pass% %ip%
exit
